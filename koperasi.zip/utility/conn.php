<?php
$dbUser = "root";
$dbPass = "";
$dbName = "db_koperasi";
$dbHost = "localhost";

mysql_connect($dbHost, $dbUser, $dbPass);
mysql_select_db($dbName);
?>

