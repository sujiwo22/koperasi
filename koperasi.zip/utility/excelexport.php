<?php
//memasukkan data dari file data.php
include('data.php');
?>
<p><a href="export.php"><button>Export Data ke Excel</button></a></p>