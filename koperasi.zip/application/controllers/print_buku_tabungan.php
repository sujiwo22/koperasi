<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class print_buku_tabungan extends OPPController
{
	public function __construct()
	{
		parent::__construct();
		$this->load->helper('fungsi');
		$this->load->model('general_m');
		$this->load->model('print_buku_tabungan_m');
	}

	public function index()
	{
		$this->load->library("pagination");

		$this->data['judul_browser'] = 'Print Buku Tabungan';
		$this->data['judul_utama'] = 'Print Buku Tabungan';
		$this->data['judul_sub'] = 'Print detail buku tabungan';

		$this->data['css_files'][] = base_url() . 'assets/easyui/themes/default/easyui.css';
		$this->data['css_files'][] = base_url() . 'assets/easyui/themes/icon.css';
		$this->data['js_files'][] = base_url() . 'assets/easyui/jquery.easyui.min.js';

		#include tanggal
		$this->data['css_files'][] = base_url() . 'assets/extra/bootstrap_date_time/css/bootstrap-datetimepicker.min.css';
		$this->data['js_files'][] = base_url() . 'assets/extra/bootstrap_date_time/js/bootstrap-datetimepicker.min.js';
		$this->data['js_files'][] = base_url() . 'assets/extra/bootstrap_date_time/js/locales/bootstrap-datetimepicker.id.js';

		#include seach
		$this->data['css_files'][] = base_url() . 'assets/theme_admin/css/daterangepicker/daterangepicker-bs3.css';
		$this->data['js_files'][] = base_url() . 'assets/theme_admin/js/plugins/daterangepicker/daterangepicker.js';

		$config = array();
		// $jumlah_row = 0;
		if (isset($_GET['anggota_id']) && $_GET['anggota_id'] > 0) {
			$id_anggota = $_GET['anggota_id'];
			$config["base_url"] = base_url() . "print_buku_tabungan/index/" . $id_anggota . "/halaman";
		} else {
			$id_anggota = $this->uri->segment(3);
			$config["base_url"] = base_url() . "print_buku_tabungan/index/" . $id_anggota . "/halaman";
		}
		$jumlah_row = $this->print_buku_tabungan_m->get_jml_data_buku($id_anggota);
		$config["total_rows"] = $jumlah_row; // banyak data
		$config["per_page"] = 10;
		$config["uri_segment"] = 5;
		$config['use_page_numbers'] = TRUE;

		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';

		$config['first_link'] = '&laquo; First';
		$config['first_tag_open'] = '<li class="prev page">';
		$config['first_tag_close'] = '</li>';

		$config['last_link'] = 'Last &raquo;';
		$config['last_tag_open'] = '<li class="next page">';
		$config['last_tag_close'] = '</li>';

		$config['next_link'] = 'Next &rarr;';
		$config['next_tag_open'] = '<li class="next page">';
		$config['next_tag_close'] = '</li>';

		$config['prev_link'] = '&larr; Previous';
		$config['prev_tag_open'] = '<li class="prev page">';
		$config['prev_tag_close'] = '</li>';

		$config['cur_tag_open'] = '<li class="active"><a href="">';
		$config['cur_tag_close'] = '</a></li>';

		$config['num_tag_open'] = '<li class="page">';
		$config['num_tag_close'] = '</li>';

		$this->pagination->initialize($config);
		$offset = ($this->uri->segment(5)) ? $this->uri->segment(5) : 0;
		if ($offset > 0) {
			$offset = ($offset * $config['per_page']) - $config['per_page'];
		}
		$this->data["data_anggota"] = $this->print_buku_tabungan_m->get_data_buku($config["per_page"], $offset, $id_anggota); // panggil seluruh data aanggota
		$this->data["halaman"] = $this->pagination->create_links();
		$this->data["offset"] = $offset;

		$this->data["id_anggota"] = $id_anggota;

		$this->data["data_jns_simpanan"] = $this->print_buku_tabungan_m->get_jenis_simpan(); // panggil seluruh data simpanan

		$this->data['isi'] = $this->load->view('print_buku_tabungan_v', $this->data, TRUE);
		$this->load->view('themes/layout_utama_v', $this->data);
	}


	function cetak_laporan()
	{
		$anggota = $this->print_buku_tabungan_m->lap_data_buku();
		$start = $_GET['baris'];
		// $data_jns_simpanan = $this->lap_kas_anggota_m->get_jenis_simpan();

		if ($anggota == FALSE) {
			redirect('print_buku_tabungan');
			exit();
		}
		$this->load->library('Pdf');
		$pdf = new Pdf('P', 'mm', 'A6', true, 'UTF-8', false);
		$pdf->set_nsi_header(false);
		$pdf->AddPage('P');
		$html = '';
		$html .= '
         <style>
             .h_tengah {text-align: center;}
             .h_kiri {text-align: left;}
             .h_kanan {text-align: right;}
             .txt_judul {font-size: 15pt; font-weight: bold; padding-bottom: 12px;}
             .header_kolom {background-color: #cccccc; text-align: center; font-weight: bold;}
         </style>
         <table width="100%" cellspacing="0" cellpadding="3" border="0">
         ';
		$no = 1;
		$batas = 1;
		if ($start > 0) {
			for ($i = 0; $i <= $start; $i++) {
				$html .= '<tr><td colspan="6"></td></tr>';
			}
		}
		foreach ($anggota as $row) {
			if ($row->debet <> 0) {
				$sandi = '02';
			} else {
				$sandi = '01';
			}
			$html .= '
				<tr>
					<td width="5%">' . $sandi . '</td>
					<td width="20%">' . $row->tgl_transaksi . '</td>
					<td width="20%" class="h_kanan">' . number_format($row->debet, 0, ',', '.') . '</td>
					<td width="20%" class="h_kanan">' . number_format($row->kredit, 0, ',', '.') . '</td>
					<td width="20%" class="h_kanan">' . number_format($row->saldo, 0, ',', '.') . '</td>
					<td width="15%"></td>
				</tr>
				';
		}
		$html .= '</table>';
		$pdf->nsi_html($html);
		$pdf->Output('print_buku_tab' . date('Ymd_His') . '.pdf', 'I');
	}
}
